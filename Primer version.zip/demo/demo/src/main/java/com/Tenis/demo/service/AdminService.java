package com.Tenis.demo.service;

import com.Tenis.demo.model.entities.Torneo;
import com.Tenis.demo.repository.TorneoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AdminService {
    @Autowired
    private TorneoRepository torneoRepository;

    @Transactional
    public void crearTorneo(Torneo torneo) {
        torneoRepository.save(torneo);
    }

    // Método: generarRondas()
    public void generarRondas(int idTorneo) {
        Torneo torneo = torneoRepository.findById(idTorneo)
                .orElseThrow(() -> new RuntimeException("Torneo no encontrado"));
        // Lógica para crear emparejamientos automáticos...
        System.out.println("Generando rondas para torneo: " + torneo.getNombre());
    }

    // Método: asignarSiembras()
    public void asignarSiembras(int idTorneo) {
        // Lógica para asignar cabezas de serie...
    }
}