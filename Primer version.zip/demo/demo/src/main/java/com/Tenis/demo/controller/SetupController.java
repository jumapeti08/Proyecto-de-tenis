package com.Tenis.demo.controller;

import com.Tenis.demo.model.entities.Administrador;
import com.Tenis.demo.model.entities.Rol;
import com.Tenis.demo.model.entities.TokenUsuario;
import com.Tenis.demo.repository.RolRepository;
import com.Tenis.demo.repository.TokenRepository;
import com.Tenis.demo.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class SetupController {

    @Autowired
    private UsuarioRepository usuarioRepository;
    
    @Autowired
    private RolRepository rolRepository;
    
    @Autowired
    private TokenRepository tokenRepository;

    @PostMapping("/setup-usuarios")
    public ResponseEntity<?> crearUsuariosPrueba() {
        try {
            // Limpiar datos previos para evitar duplicados en la base de datos en memoria
            usuarioRepository.deleteAll();
            tokenRepository.deleteAll();
            rolRepository.deleteAll();

            // Crear rol Administrador
            Rol rolAdmin = new Rol();
            rolAdmin.setNombre("ADMINISTRADOR");
            rolRepository.save(rolAdmin);

            // Crear rol Juez
            Rol rolJuez = new Rol();
            rolJuez.setNombre("JUEZ");
            rolRepository.save(rolJuez);

            // Crear token para administrador
            TokenUsuario tokenAdmin = new TokenUsuario();
            tokenAdmin.setContenido("token_admin_12345");
            tokenAdmin.setExpiracion("2026-12-31");
            tokenAdmin.setRol(rolAdmin);

            // Crear token para juez
            TokenUsuario tokenJuez = new TokenUsuario();
            tokenJuez.setContenido("token_juez_12345");
            tokenJuez.setExpiracion("2026-12-31");
            tokenJuez.setRol(rolJuez);

            // Crear usuario Administrador
            Administrador admin = new Administrador();
            admin.setUsuario("admin");
            admin.setPassword("admin123");
            admin.setToken(tokenAdmin);
            usuarioRepository.save(admin);

            // Crear usuario Juez
            Administrador juez = new Administrador();
            juez.setUsuario("juez");
            juez.setPassword("juez123");
            juez.setToken(tokenJuez);
            usuarioRepository.save(juez);

            return ResponseEntity.ok(new SetupResponse(
                true,
                "Usuarios de prueba creados exitosamente",
                "Administrador: admin / admin123",
                "Juez: juez / juez123"
            ));
        } catch (Exception e) {
            return ResponseEntity.status(400).body(new SetupResponse(
                false,
                "Error al crear usuarios: " + e.getMessage(),
                "",
                ""
            ));
        }
    }

    static class SetupResponse {
        public boolean success;
        public String message;
        public String admin;
        public String juez;

        public SetupResponse(boolean success, String message, String admin, String juez) {
            this.success = success;
            this.message = message;
            this.admin = admin;
            this.juez = juez;
        }
    }
}
