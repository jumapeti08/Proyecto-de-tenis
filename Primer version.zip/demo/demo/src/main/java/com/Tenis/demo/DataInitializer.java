package com.Tenis.demo;

import com.Tenis.demo.model.entities.Administrador;
import com.Tenis.demo.model.entities.Rol;
import com.Tenis.demo.model.entities.TokenUsuario;
import com.Tenis.demo.repository.RolRepository;
import com.Tenis.demo.repository.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initDatabase(UsuarioRepository usuarioRepository, 
                                   RolRepository rolRepository) {
        return args -> {
            try {
                if (usuarioRepository.count() == 0) {
                    System.out.println("--- [DB SETUP] Iniciando creación de usuarios... ---");

                    // 1. Crear Roles
                    Rol rolAdmin = new Rol();
                    rolAdmin.setIdRol(1); 
                    rolAdmin.setNombre("ADMINISTRADOR");
                    rolRepository.save(rolAdmin);

                    Rol rolJuez = new Rol();
                    rolJuez.setIdRol(2);
                    rolJuez.setNombre("JUEZ");
                    rolRepository.save(rolJuez);

                    Rol rolJugador = new Rol();
                    rolJugador.setIdRol(3);
                    rolJugador.setNombre("JUGADOR");
                    rolRepository.save(rolJugador);

                    // 2. Crear Tokens
                    TokenUsuario tokenAdmin = new TokenUsuario();
                    tokenAdmin.setContenido("token_admin_123");
                    tokenAdmin.setExpiracion("2026-12-31");
                    tokenAdmin.setRol(rolAdmin);

                    TokenUsuario tokenJuez = new TokenUsuario();
                    tokenJuez.setContenido("token_juez_123");
                    tokenJuez.setExpiracion("2026-12-31");
                    tokenJuez.setRol(rolJuez);

                    // 3. Crear Usuarios
                    Administrador admin = new Administrador();
                    admin.setUsuario("admin");
                    admin.setPassword("admin123");
                    admin.setToken(tokenAdmin);
                    usuarioRepository.save(admin);

                    Administrador juez = new Administrador();
                    juez.setUsuario("juez");
                    juez.setPassword("juez123");
                    juez.setToken(tokenJuez);
                    usuarioRepository.save(juez);

                    System.out.println("--- [DB SETUP] ¡Usuarios creados con éxito! ---");
                } else {
                    System.out.println("--- [DB SETUP] Los usuarios ya existen en la base de datos. ---");
                }
            } catch (Exception e) {
                System.err.println("--- [DB SETUP ERROR] No se pudieron inicializar los datos: " + e.getMessage());
            }
        };
    }
}