package com.Tenis.demo.model.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "partidos")
public class Partido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idPartido;
    
    private String resultado;
    private String estado;
    
    public Partido() {}
    
    public Partido(String resultado, String estado) {
        this.resultado = resultado;
        this.estado = estado;
    }
    
    // Getters y Setters
    public int getIdPartido() {
        return idPartido;
    }
    
    public void setIdPartido(int idPartido) {
        this.idPartido = idPartido;
    }
    
    public String getResultado() {
        return resultado;
    }
    
    public void setResultado(String resultado) {
        this.resultado = resultado;
    }
    
    public String getEstado() {
        return estado;
    }
    
    public void setEstado(String estado) {
        this.estado = estado;
    }
}
