package com.Tenis.demo.service;

import com.Tenis.demo.model.entities.Partido;
import com.Tenis.demo.repository.PartidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TorneoService {
    @Autowired
    private PartidoRepository partidoRepository;

    // Método Juez: confirmarResultado()
    public void confirmarResultado(int idPartido) {
        Partido partido = partidoRepository.findById(idPartido)
                .orElseThrow(() -> new RuntimeException("Partido no encontrado con ID: " + idPartido));
                
        partido.setEstado("FINALIZADO");
        partidoRepository.save(partido);
    }

    // Método Jugador: consultarHistorial()
    //public List<Estadistica> consultarHistorial(Jugador jugador) {
    //    return jugador.getEstadisticas();
    //}
}