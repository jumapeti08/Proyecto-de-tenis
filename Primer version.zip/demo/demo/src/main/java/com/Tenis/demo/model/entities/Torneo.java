package com.Tenis.demo.model.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "torneos")
public class Torneo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idTorneo;
    
    private String nombre;
    private String descripcion;
    private String estado;
    
    public Torneo() {}
    
    public Torneo(String nombre, String descripcion, String estado) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.estado = estado;
    }
    
    // Getters y Setters
    public int getIdTorneo() {
        return idTorneo;
    }
    
    public void setIdTorneo(int idTorneo) {
        this.idTorneo = idTorneo;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getDescripcion() {
        return descripcion;
    }
    
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    public String getEstado() {
        return estado;
    }
    
    public void setEstado(String estado) {
        this.estado = estado;
    }
}
