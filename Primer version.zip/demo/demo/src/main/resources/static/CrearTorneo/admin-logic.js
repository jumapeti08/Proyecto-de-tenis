let totalRondasGlobal = 0;

function calcularPartidos() {
    const numRondas = parseInt(document.getElementById('numRondas').value);
    const tabsContainer = document.getElementById('tabsRondas');
    const info = document.getElementById('infoPartidos');
    
    if (numRondas > 0 && numRondas <= 7) {
        totalRondasGlobal = numRondas;
        info.innerText = `Estructura: ${Math.pow(2, numRondas)} jugadores totales.`;
        
        tabsContainer.innerHTML = "";
        for (let i = 1; i <= numRondas; i++) {
            const label = (i === numRondas) ? "Final" : (i === numRondas-1) ? "Semis" : `Ronda ${i}`;
            tabsContainer.innerHTML += `
                <button class="tab-button ${i === 1 ? 'active' : ''}" onclick="mostrarRonda(${i}, this)">
                    ${label}
                </button>
            `;
        }
        mostrarRonda(1);
    }
}

function toggleSiembras() {
    const seccion = document.getElementById('seccionSiembras');
    seccion.style.display = (document.getElementById('haySiembras').value === 'si') ? 'block' : 'none';
}

function generarCamposSiembras() {
    const cantidad = document.getElementById('cantSiembras').value;
    const contenedor = document.getElementById('contenedorCamposSiembras');
    contenedor.innerHTML = "";
    for (let i = 1; i <= cantidad; i++) {
        contenedor.innerHTML += `
            <div style="display: flex; gap: 5px; margin-bottom: 8px;">
                <input type="text" placeholder="Nombre Siembra ${i}" id="seed_name_${i}">
                <input type="number" placeholder="Llave R2" id="seed_llave_${i}" style="width: 100px;">
            </div>`;
    }
}

function mostrarRonda(rondaActual, elemento = null) {
    const contenedor = document.getElementById('contenedorLlaves');
    const haySiembras = document.getElementById('haySiembras').value === 'si';
    
    if (elemento) {
        document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
        elemento.classList.add('active');
    }

    const partidosEnEstaRonda = Math.pow(2, totalRondasGlobal - rondaActual);
    contenedor.innerHTML = "";
    
    for (let i = 1; i <= partidosEnEstaRonda; i++) {
        let nJ1 = "", nJ2 = "";
        let bJ1 = (rondaActual > 1), bJ2 = (rondaActual > 1);
        let esSiembraR1 = false;

        if (haySiembras) {
            const cant = document.getElementById('cantSiembras').value;
            for (let s = 1; s <= cant; s++) {
                let nomS = document.getElementById(`seed_name_${s}`)?.value || `Siembra ${s}`;
                let llaveS = parseInt(document.getElementById(`seed_llave_${s}`)?.value);

                // En RONDA 2: Ponemos a la siembra en el lugar J1 de la llave elegida
                if (rondaActual === 2 && i === llaveS) {
                    nJ1 = nomS; nJ2 = "Ganador R1-L" + (llaveS * 2);
                    bJ1 = bJ2 = true;
                }
                // En RONDA 1: Bloqueamos SOLO la llave impar que alimenta ese puesto de R2
                if (rondaActual === 1 && i === (llaveS * 2 - 1)) {
                    nJ1 = nomS; nJ2 = "--- (BYE) ---";
                    bJ1 = bJ2 = esSiembraR1 = true;
                }
            }
        }

        if (rondaActual > 1 && nJ1 === "") { nJ1 = "Ganador anterior"; nJ2 = "Ganador anterior"; }

        contenedor.innerHTML += `
            <div class="llave-item ${esSiembraR1 ? 'siembra-card' : ''}">
                <span style="min-width: 55px; font-size: 0.7rem; color: #888;">R${rondaActual}-L${i}</span>
                <input type="text" value="${nJ1}" placeholder="Jugador 1" ${bJ1 ? 'disabled class="input-bloqueado"' : ''}>
                <span class="vs">VS</span>
                <input type="text" value="${nJ2}" placeholder="Jugador 2" ${bJ2 ? 'disabled class="input-bloqueado"' : ''}>
            </div>`;
    }
}

function guardarTorneo() {
    const cat = document.getElementById('categoriaTorneo').value;
    if(!cat) return alert("Selecciona categoría");
    alert("¡Torneo " + cat + " creado con éxito!");
    window.location.href = "../admin.html";
}