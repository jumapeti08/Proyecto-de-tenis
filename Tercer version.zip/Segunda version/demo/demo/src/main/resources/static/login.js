console.log("Script login.js cargado e iniciando...");

document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault(); // Evita que el formulario recargue la página

    const usuario = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
        // Enviamos la petición al AuthController de Spring Boot
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ usuario, password })
        });

        if (response.ok) {
            const tokenUsuario = await response.json(); // Recibimos el TokenUsuario
            
            // Guardamos el token y el rol en localStorage para persistir la sesión
            localStorage.setItem('sessionToken', tokenUsuario.contenido);
            localStorage.setItem('userRole', tokenUsuario.rol.nombre);

            // Redirigimos según el rol recibido del backend
            redirigirUsuario(tokenUsuario.rol.nombre);
        } else {
            alert("Credenciales incorrectas. Intente de nuevo.");
        }
    } catch (error) {
        console.error("Error en la conexión:", error);
        alert("No se pudo conectar con el servidor.");
    }
});

function redirigirUsuario(rol) {
    switch(rol) {
        case 'ADMINISTRADOR':
            // Entra a la carpeta CrearTorneo y abre Admin.html
            window.location.href = '/CrearTorneo/Admin.html';
            break;
            
        case 'JUEZ':
            // Nueva pantalla de selección para el juez
            window.location.href = '/Juez/panel-juez.html';
            break;
            
        case 'JUGADOR':
            window.location.href = '/Jugador/perfil.html';
            break;
            
        default:
            alert("Rol no reconocido");
            window.location.href = '/index.html';
    }
}

// Función global para el botón de setup
window.ejecutarSetup = async function() {
    console.log("Iniciando setup manual...");
    try {
        const response = await fetch('/api/setup-usuarios', { method: 'POST' });
        const data = await response.json();
        if (data.success) {
            alert("¡Éxito!\n" + data.admin + "\n" + data.juez + "\n" + data.jugador);
        } else {
            alert("Error: " + data.message);
        }
    } catch (error) {
        alert("Error de conexión. Mira la consola (F12).");
    }
};