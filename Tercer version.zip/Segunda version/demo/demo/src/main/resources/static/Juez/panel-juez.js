document.addEventListener('DOMContentLoaded', cargarTorneos);

async function cargarTorneos() {
    const container = document.getElementById('listaTorneos');
    try {
        const response = await fetch('/api/torneos/activos');
        const torneos = await response.json();

        if (torneos.length === 0) {
            container.innerHTML = '<p style="text-align:center">No hay torneos activos en este momento.</p>';
            return;
        }

        torneos.forEach(torneo => {
            const card = document.createElement('div');
            card.className = 'tournament-card';
            card.innerHTML = `
                <h3>${torneo.nombre} <span>(${torneo.categoria})</span></h3>
                <p>Estado: ${torneo.estado}</p>
                <div id="matches-${torneo.id}" class="match-list"></div>
            `;
            card.onclick = () => cargarPartidos(torneo.id);
            container.appendChild(card);
        });
    } catch (error) {
        console.error("Error cargando torneos:", error);
    }
}

async function cargarPartidos(torneoId) {
    const matchContainer = document.getElementById(`matches-${torneoId}`);
    if (matchContainer.innerHTML !== "") { matchContainer.innerHTML = ""; return; }

    try {
        const response = await fetch(`/api/torneos/${torneoId}`);
        const torneo = await response.json();

        torneo.rondas.forEach(ronda => {
            matchContainer.innerHTML += `<h4 style="color: var(--ball-yellow); margin-top:10px;">${ronda.nombreRonda}</h4>`;
            ronda.partidos.forEach(partido => {
                let nombres = "";
                if (partido.jugador1) {
                    nombres = `${partido.jugador1.nombre} vs ${partido.jugador2.nombre}`;
                } else if (partido.pareja1) {
                    nombres = `${partido.pareja1.jugador1.nombre}/${partido.pareja1.jugador2.nombre} vs 
                               ${partido.pareja2.jugador1.nombre}/${partido.pareja2.jugador2.nombre}`;
                }

                matchContainer.innerHTML += `
                    <div class="match-item">
                        <span>${nombres}</span>
                        <button class="btn-arbitrar" onclick="event.stopPropagation(); window.location.href='index.html?matchId=${partido.id}'">Arbitrar</button>
                    </div>`;
            });
        });
    } catch (error) {
        console.error("Error cargando partidos:", error);
    }
}