// --- VARIABLES DE ESTADO ---
let puntos1 = 0, puntos2 = 0;
let game1 = 0, game2 = 0;
let set1 = 0, set2 = 0;
let tieBreak = false;
let superTieBreak = false;
let quienSirve = 0; 
let quienInicioRecibiendoTie = 0; // Para saber quién saca en el próximo set
let puntosServidosEnTie = 0; // Contador para rotar cada 2 puntos

// --- OBJETOS DE ESTADÍSTICA ---
let statsJugador1 = { ace: 0, dobleFalta: 0, errorNo: 0, red: 0, winner: 0 };
let statsJugador2 = { ace: 0, dobleFalta: 0, errorNo: 0, red: 0, winner: 0 };

// Variable para nombres reales
let nombreRealJ1 = "Jugador 1";
let nombreRealJ2 = "Jugador 2";

function preguntarServicio(n1, n2) {
    nombreRealJ1 = n1 || "Jugador 1";
    nombreRealJ2 = n2 || "Jugador 2";
    
    let seleccion = prompt(`¿Quién inicia sirviendo?\n\n1 - ${nombreRealJ1}\n2 - ${nombreRealJ2}\n\nIngresa el número (1 o 2):`);
    if (seleccion === "1" || seleccion === "2") {
        quienSirve = parseInt(seleccion);
        actualizarBotonesServicio();
    } else if (seleccion !== null) { preguntarServicio(n1, n2); }
}

function actualizarBotonesServicio() {
    const j1Buttons = document.querySelectorAll('.jugador')[0].querySelectorAll('.ace, .doble');
    const j2Buttons = document.querySelectorAll('.jugador')[1].querySelectorAll('.ace, .doble');

    if (quienSirve === 1) {
        j1Buttons.forEach(btn => { btn.disabled = false; btn.style.opacity = "1"; });
        j2Buttons.forEach(btn => { btn.disabled = true; btn.style.opacity = "0.3"; });
    } else {
        j2Buttons.forEach(btn => { btn.disabled = false; btn.style.opacity = "1"; });
        j1Buttons.forEach(btn => { btn.disabled = true; btn.style.opacity = "0.3"; });
    }
}

function registrarStat(jugador, tipo) {
    const s = (jugador === 1) ? statsJugador1 : statsJugador2;
    s[tipo]++;
    
    if (tipo === 'ace' || tipo === 'winner') (jugador === 1) ? sumarJugador1() : sumarJugador2();
    else if (tipo === 'dobleFalta' || tipo === 'errorNo' || tipo === 'red') (jugador === 1) ? sumarJugador2() : sumarJugador1();
}

// --- LÓGICA DE SUMA DE PUNTOS ---
function sumarJugador1() {
    if (superTieBreak) { manejarSuperTieBreak(1); return; }
    if (tieBreak) { manejarTieBreak(1); return; }

    puntos1++;
    if ((puntos1 >= 4 && puntos1 - puntos2 >= 2) || (puntos1 === 5 && puntos2 === 4)) {
        game1++;
        document.getElementById("sumarGameJug1").innerText = game1;
        quienSirve = (quienSirve === 1) ? 2 : 1;
        actualizarBotonesServicio();
        resetPuntos();
        verificarSet();
    } else { actualizarPuntajes(); }
}

function sumarJugador2() {
    if (superTieBreak) { manejarSuperTieBreak(2); return; }
    if (tieBreak) { manejarTieBreak(2); return; }

    puntos2++;
    if ((puntos2 >= 4 && puntos2 - puntos1 >= 2) || (puntos2 === 5 && puntos1 === 4)) {
        game2++;
        document.getElementById("sumarGameJug2").innerText = game2;
        quienSirve = (quienSirve === 1) ? 2 : 1;
        actualizarBotonesServicio();
        resetPuntos();
        verificarSet();
    } else { actualizarPuntajes(); }
}

// --- TIE-BREAK (A 7) ---
function manejarTieBreak(ganadorPunto) {
    (ganadorPunto === 1) ? puntos1++ : puntos2++;
    puntosServidosEnTie++;

    // Rotación de saque: 1er punto saca quien tocaba, luego cada 2 puntos
    if (puntosServidosEnTie === 1 || (puntosServidosEnTie > 1 && (puntosServidosEnTie - 1) % 2 === 0)) {
        quienSirve = (quienSirve === 1) ? 2 : 1;
        actualizarBotonesServicio();
    }

    document.getElementById("puntaje1").innerText = puntos1;
    document.getElementById("puntaje2").innerText = puntos2;
    document.getElementById("estado").innerText = "TIE-BREAK";

    if (puntos1 >= 7 && puntos1 - puntos2 >= 2) finalizarSet(1);
    else if (puntos2 >= 7 && puntos2 - puntos1 >= 2) finalizarSet(2);
}

// --- SUPER TIE-BREAK (A 10) ---
function manejarSuperTieBreak(ganadorPunto) {
    (ganadorPunto === 1) ? puntos1++ : puntos2++;
    puntosServidosEnTie++;

    if (puntosServidosEnTie === 1 || (puntosServidosEnTie > 1 && (puntosServidosEnTie - 1) % 2 === 0)) {
        quienSirve = (quienSirve === 1) ? 2 : 1;
        actualizarBotonesServicio();
    }

    document.getElementById("puntaje1").innerText = puntos1;
    document.getElementById("puntaje2").innerText = puntos2;
    document.getElementById("estado").innerText = "SUPER TIE-BREAK (A 10)";

    if (puntos1 >= 10 && puntos1 - puntos2 >= 2) { set1++; chequearPartido(); }
    else if (puntos2 >= 10 && puntos2 - puntos1 >= 2) { set2++; chequearPartido(); }
}

function verificarSet() {
    if ((game1 >= 6 && game1 - game2 >= 2) || game1 === 7) finalizarSet(1);
    else if ((game2 >= 6 && game2 - game1 >= 2) || game2 === 7) finalizarSet(2);
    else if (game1 === 6 && game2 === 6) {
        tieBreak = true;
        puntosServidosEnTie = 0;
        quienInicioRecibiendoTie = (quienSirve === 1) ? 1 : 2; 
        alert("🎾 ¡Tie-break!");
    }
}

function finalizarSet(ganador) {
    (ganador === 1) ? set1++ : set2++;
    document.getElementById("setJug1").innerText = set1;
    document.getElementById("setJug2").innerText = set2;
    
    // Al terminar Tie-break, sirve quien inició recibiendo el tie
    if (tieBreak) {
        quienSirve = quienInicioRecibiendoTie;
        actualizarBotonesServicio();
    }

    tieBreak = false;
    reiniciarGames();
    chequearPartido();
}

function chequearPartido() {
    if (set1 === 2 || set2 === 2) {
        mostrarInterfazStats();
    } else if (set1 === 1 && set2 === 1) {
        superTieBreak = true;
        puntosServidosEnTie = 0;
        alert("🎾 ¡Súper Tie-break a 10 puntos!");
    }
}

// --- UTILIDADES RESTANTES ---
function actualizarPuntajes() {
    const p1 = document.getElementById("puntaje1");
    const p2 = document.getElementById("puntaje2");
    const estado = document.getElementById("estado");

    if (puntos1 === 4 && puntos2 === 4) {
        p1.innerText = "AD"; p2.innerText = "AD";
        estado.innerText = "¡PUNTO DECISIVO!";
    } else if (puntos1 === 4 && puntos2 === 3) {
        p1.innerText = "AD"; p2.innerText = "40";
        estado.innerText = "Ventaja J1";
    } else if (puntos2 === 4 && puntos1 === 3) {
        p1.innerText = "40"; p2.innerText = "AD";
        estado.innerText = "Ventaja J2";
    } else {
        p1.innerText = cambiarPunto(puntos1);
        p2.innerText = cambiarPunto(puntos2);
        estado.innerText = (puntos1 === 3 && puntos2 === 3) ? "DEUCE" : "";
    }
}

function resetPuntos() { puntos1 = 0; puntos2 = 0; actualizarPuntajes(); }
function reiniciarGames() { 
    game1 = 0; game2 = 0; resetPuntos(); 
    document.getElementById("sumarGameJug1").innerText = "0";
    document.getElementById("sumarGameJug2").innerText = "0";
}

function cambiarPunto(num) {
    const t = ["0", "15", "30", "40"];
    return t[num] || "40";
}

function mostrarInterfazStats() {
    document.getElementById("tabla-j1").innerHTML = crearFilas(statsJugador1);
    document.getElementById("tabla-j2").innerHTML = crearFilas(statsJugador2);
    document.getElementById("modal-stats").style.display = "flex";
}

function crearFilas(obj) {
    const nombres = { ace: "Aces", dobleFalta: "D. Faltas", errorNo: "Errores NF", red: "Red", winner: "Winners" };
    let html = "";
    for (let key in obj) html += `<tr><td>${nombres[key]}</td><td>${obj[key]}</td></tr>`;
    return html;
}

function cerrarStats() { location.reload(); } // Recarga para limpiar todo el estado