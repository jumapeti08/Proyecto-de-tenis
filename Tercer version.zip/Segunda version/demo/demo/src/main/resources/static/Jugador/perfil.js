// JS para la página de perfil de jugador
console.log('perfil.js cargado');

const toggleBtn = document.getElementById('toggleBtn');
const drawer = document.getElementById('drawer');
const btnMiPerfil = document.getElementById('btnMiPerfil');
const btnTorneos = document.getElementById('btnTorneos');
const btnBuscarJugadores = document.getElementById('btnBuscarJugadores');
const areaMiPerfil = document.getElementById('areaMiPerfil');
const areaTorneos = document.getElementById('areaTorneos');
const areaBuscar = document.getElementById('areaBuscar');

function openDrawer(){ drawer.classList.add('open'); drawer.setAttribute('aria-hidden','false'); }
function closeDrawer(){ drawer.classList.remove('open'); drawer.setAttribute('aria-hidden','true'); }

toggleBtn.addEventListener('click', ()=>{
  if(drawer.classList.contains('open')) closeDrawer(); else openDrawer();
});

btnMiPerfil.addEventListener('click', ()=>{ showArea('perfil'); closeDrawer(); });
btnTorneos.addEventListener('click', ()=>{ showArea('torneos'); loadTorneos(); closeDrawer(); });
btnBuscarJugadores.addEventListener('click', ()=>{ showArea('buscar'); closeDrawer(); });

function showArea(a){
  areaMiPerfil.style.display='none'; areaTorneos.style.display='none'; areaBuscar.style.display='none';
  if(a==='perfil') areaMiPerfil.style.display='block';
  if(a==='torneos') areaTorneos.style.display='block';
  if(a==='buscar') areaBuscar.style.display='block';
  // scroll to top of main area on mobile
  window.scrollTo({top:0,behavior:'smooth'});
}

// Cargar mis estadísticas usando jugadorId desde localStorage
async function cargarMiEstadistica() {
  const id = localStorage.getItem('jugadorId');
  const cont = document.getElementById('miEstadisticas');
  if (!id) { cont.innerText = 'No se encontró `jugadorId` en localStorage. Usa Buscar para localizar tu jugador.'; return; }
  cont.innerText = 'Cargando...';
  try {
    const res = await fetch(`/api/jugadores/${id}/estadisticas`);
    if (!res.ok) throw new Error('No encontrado');
    const d = await res.json();
    cont.innerHTML = `
      <div><strong>Total partidos:</strong> ${d.totalPartidos}</div>
      <div style="margin-top:8px"><strong>Partidos (id):</strong> ${d.partidos.map(p=>p.id).join(', ')}</div>
    `;
  } catch (e) {
    cont.innerText = 'Error cargando estadísticas: ' + e;
  }
}

// Cargar torneos
async function loadTorneos(){
  const lista = document.getElementById('listaTorneos');
  lista.innerText = 'Cargando...';
  try{
    const res = await fetch('/api/torneos/all');
    const torneos = await res.json();
    if(!Array.isArray(torneos) || torneos.length===0) { lista.innerText='No hay torneos'; return; }
    lista.innerHTML = '';
    let openMatchesContainer = null; // container currently open
    torneos.forEach(t=>{
      const el = document.createElement('div');
      el.className='card';
      el.style.margin='6px 0';
      el.innerHTML = `
        <div style="display:flex;justify-content:space-between;align-items:center">
          <div><strong style="font-size:16px">${t.nombre}</strong><br/><small style="color:var(--muted)">${t.categoria || '—'}</small></div>
          <div style="display:flex;gap:8px;align-items:center">
            <button class='btn' data-id='${t.id}' data-action='toggle'>Ver partidos</button>
            <button class='btn btn-ghost' data-id='${t.id}' data-action='full'>Abrir</button>
          </div>
        </div>
      `;
      // container to render matches just below this tournament
      const matchesContainer = document.createElement('div');
      matchesContainer.style.display = 'none';
      matchesContainer.style.marginTop = '8px';
      // attach handlers
      el.querySelectorAll('button').forEach(btn => {
        const action = btn.dataset.action;
        if(action === 'toggle') btn.addEventListener('click', ()=>{
          if(matchesContainer.style.display === 'none'){
            // close previous
            if(openMatchesContainer && openMatchesContainer !== matchesContainer) openMatchesContainer.style.display = 'none';
            openMatchesContainer = matchesContainer;
            matchesContainer.style.display = 'block';
            loadPartidosTorneo(t.id, matchesContainer);
          } else {
            matchesContainer.style.display = 'none';
            openMatchesContainer = null;
          }
        });
        if(action === 'full') btn.addEventListener('click', ()=>{
          openTorneoFull(t.id, t.nombre);
        });
      });
      lista.appendChild(el);
      lista.appendChild(matchesContainer);
    });
  }catch(e){ lista.innerText='Error al cargar torneos: '+e }
}

async function loadPartidosTorneo(torneoId, renderContainer){
  const cont = renderContainer || document.getElementById('partidosTorneo');
  cont.innerHTML = '';
  cont.innerText = 'Cargando cuadro...';
  try{
    const res = await fetch(`/api/torneos/${torneoId}`);
    if(!res.ok) { cont.innerText='No se encontró el torneo'; return; }
    const torneo = await res.json();
    if(!torneo || !Array.isArray(torneo.rondas) || torneo.rondas.length===0) { cont.innerText='No hay rondas o partidos en este torneo'; return; }
    torneo.rondas.sort((a,b)=> (a.numeroRonda||0)-(b.numeroRonda||0));
    cont.innerHTML = '';
    torneo.rondas.forEach(r=>{
      const rondaDiv = document.createElement('div');
      rondaDiv.className = 'card';
      rondaDiv.style.margin = '6px 0';
      const titulo = r.nombreRonda || (`Ronda ${r.numeroRonda||'?'}`);
      let inner = `<h4 style="margin-top:0">${titulo}</h4>`;
      if(!Array.isArray(r.partidos) || r.partidos.length===0){ inner += '<div style="color:var(--muted)">Sin partidos</div>'; }
      else{
        inner += '<div style="display:flex;flex-direction:column;gap:8px">';
        r.partidos.forEach(p=>{
          let jugadorA = '—';
          let jugadorB = '—';
          if(p.jugador1 && p.jugador1.nombre) jugadorA = p.jugador1.nombre;
          if(p.jugador2 && p.jugador2.nombre) jugadorB = p.jugador2.nombre;
          if(p.pareja1){
            const pa = p.pareja1;
            const nombresA = [];
            if(pa.jugador1 && pa.jugador1.nombre) nombresA.push(pa.jugador1.nombre);
            if(pa.jugador2 && pa.jugador2.nombre) nombresA.push(pa.jugador2.nombre);
            jugadorA = nombresA.join(' / ');
          }
          if(p.pareja2){
            const pb = p.pareja2;
            const nombresB = [];
            if(pb.jugador1 && pb.jugador1.nombre) nombresB.push(pb.jugador1.nombre);
            if(pb.jugador2 && pb.jugador2.nombre) nombresB.push(pb.jugador2.nombre);
            jugadorB = nombresB.join(' / ');
          }
          const resultado = p.resultado || '—';
          inner += `<div style="display:flex;justify-content:space-between;align-items:center;padding:8px;border-radius:8px;background:linear-gradient(90deg,rgba(0,0,0,0.02),rgba(0,0,0,0.01))">
                      <div><strong>${jugadorA}</strong><br/><small style='color:var(--muted)'>vs</small><br/><strong>${jugadorB}</strong></div>
                      <div style='text-align:right'><div style="font-size:12px;color:var(--muted)">${p.estado}</div><div style='margin-top:6px'>${resultado}</div></div>
                    </div>`;
        });
        inner += '</div>';
      }
      rondaDiv.innerHTML = inner;
      cont.appendChild(rondaDiv);
    });
  }catch(e){ cont.innerText='Error: '+e }
}

// Abrir vista completa del torneo
function openTorneoFull(torneoId, nombre){
  const area = document.getElementById('areaTorneoFull');
  const title = document.getElementById('torneoFullTitle');
  const content = document.getElementById('torneoFullContent');
  title.innerText = nombre || '';
  area.style.display = 'block';
  loadPartidosTorneo(torneoId, content);
}

document.getElementById('btnBackTorneo')?.addEventListener('click', ()=>{
  document.getElementById('areaTorneoFull').style.display = 'none';
});

// Búsqueda con sugerencias
const inputBuscar = document.getElementById('inputBuscar');
const sugerencias = document.getElementById('sugerencias');
let debounceTimer;
inputBuscar.addEventListener('input', (e)=>{
  const q = e.target.value.trim();
  clearTimeout(debounceTimer);
  if (q.length < 2) { sugerencias.style.display='none'; return; }
  debounceTimer = setTimeout(()=> buscarSugerencias(q), 250);
});

async function buscarSugerencias(q){
  try{
    const res = await fetch(`/api/jugadores/search?q=${encodeURIComponent(q)}`);
    if(!res.ok) throw new Error('error');
    const arr = await res.json();
    if(!Array.isArray(arr) || arr.length===0) { sugerencias.style.display='none'; return; }
    sugerencias.innerHTML = '';
    arr.forEach(j=>{
      const d = document.createElement('div'); d.className='suggestion'; d.innerText = j.nombre; d.dataset.id = j.id;
      d.addEventListener('click', ()=> seleccionarJugador(j.id, j.nombre));
      sugerencias.appendChild(d);
    });
    sugerencias.style.display='block';
  }catch(e){ console.error(e); sugerencias.style.display='none' }
}

async function seleccionarJugador(id,nombre){
  sugerencias.style.display='none';
  inputBuscar.value = nombre;
  // Abrir vista completa de jugador
  openJugadorFull(id,nombre);
}

async function openJugadorFull(id,nombre){
  const area = document.getElementById('areaJugadorFull');
  const title = document.getElementById('jugadorFullTitle');
  const content = document.getElementById('jugadorFullContent');
  title.innerText = nombre || '';
  area.style.display = 'block';
  content.innerHTML = 'Cargando estadísticas...';
  try{
    // Estadísticas resumidas
    const res = await fetch(`/api/jugadores/${id}/estadisticas`);
    const estad = res.ok ? await res.json() : null;
    // Partidos del jugador
    const res2 = await fetch(`/api/jugadores/${id}/partidos`);
    const partidos = res2.ok ? await res2.json() : [];

    let html = `<div style='display:flex;gap:12px;align-items:center'>
                  <div style='flex:1'>
                    <h3 style='margin:0'>${nombre}</h3>
                    <div style='color:var(--muted)'>ID: ${id}</div>
                  </div>
                  <div style='text-align:right'>
                    <div><strong>Total partidos</strong></div>
                    <div style='font-size:20px'>${estad?.totalPartidos ?? partidos.length}</div>
                  </div>
                </div>
                <hr />`;

    html += `<div><strong>Partidos</strong></div>`;
    if(!Array.isArray(partidos) || partidos.length===0) html += `<div style='color:var(--muted)'>No se encontraron partidos</div>`;
    else{
      html += `<div style='display:flex;flex-direction:column;gap:8px;margin-top:8px'>`;
      partidos.forEach(p=>{
        let jugadorA = '—';
        let jugadorB = '—';
        if(p.jugador1 && p.jugador1.nombre) jugadorA = p.jugador1.nombre;
        if(p.jugador2 && p.jugador2.nombre) jugadorB = p.jugador2.nombre;
        if(p.pareja1){ const pa = p.pareja1; const na=[]; if(pa.jugador1?.nombre) na.push(pa.jugador1.nombre); if(pa.jugador2?.nombre) na.push(pa.jugador2.nombre); jugadorA = na.join(' / '); }
        if(p.pareja2){ const pb = p.pareja2; const nb=[]; if(pb.jugador1?.nombre) nb.push(pb.jugador1.nombre); if(pb.jugador2?.nombre) nb.push(pb.jugador2.nombre); jugadorB = nb.join(' / '); }
        html += `<div class='card' style='display:flex;justify-content:space-between;align-items:center'>
                    <div><strong>${jugadorA}</strong><br/><small style='color:var(--muted)'>vs</small><br/><strong>${jugadorB}</strong></div>
                    <div style='text-align:right'><div style='font-size:12px;color:var(--muted)'>${p.estado}</div><div style='margin-top:6px'>${p.resultado||'—'}</div></div>
                 </div>`;
      });
      html += `</div>`;
    }

    content.innerHTML = html;

    // Hook to save as my jugador
    const saveBtn = document.getElementById('btnGuardarMiJugador');
    if(saveBtn){
      saveBtn.onclick = ()=>{
        localStorage.setItem('jugadorId', String(id));
        area.style.display = 'none';
        // actualizar perfil
        showArea('perfil'); cargarMiEstadistica();
      };
    }

  }catch(e){ content.innerText = 'Error cargando jugador: '+e }
}

document.getElementById('btnBackJugador')?.addEventListener('click', ()=>{ document.getElementById('areaJugadorFull').style.display = 'none'; });

// Al cargar la página, mostrar el área de perfil si hay jugadorId
window.addEventListener('load', ()=>{
  // Siempre mostrar la pantalla principal del jugador (estadísticas personales)
  showArea('perfil');
  cargarMiEstadistica();
  // Botón rápido para abrir búsqueda desde el perfil
  const btnAbrir = document.getElementById('btnAbrirBuscar');
  if(btnAbrir) btnAbrir.addEventListener('click', ()=>{ openDrawer(); showArea('buscar'); setTimeout(()=>{ const inp=document.getElementById('inputBuscar'); if(inp) inp.focus(); },250); });
});
