package com.Tenis.demo.repository;

import com.Tenis.demo.model.entities.Pareja;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ParejaRepository extends JpaRepository<Pareja, Long> {
}