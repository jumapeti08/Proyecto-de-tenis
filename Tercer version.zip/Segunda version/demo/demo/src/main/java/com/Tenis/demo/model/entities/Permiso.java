package com.Tenis.demo.model.entities;

import jakarta.persistence.*;

@Entity
public class Permiso {
    @Id
    private int idPermiso; //
    private String descripcion; //
    
    // Getters y Setters
    public int getIdPermiso() {
        return idPermiso;
    }
    
    public void setIdPermiso(int idPermiso) {
        this.idPermiso = idPermiso;
    }
    
    public String getDescripcion() {
        return descripcion;
    }
    
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}