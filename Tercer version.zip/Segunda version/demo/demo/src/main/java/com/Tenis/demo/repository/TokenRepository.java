package com.Tenis.demo.repository;

import com.Tenis.demo.model.entities.TokenUsuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface TokenRepository extends JpaRepository<TokenUsuario, Integer> {
    Optional<TokenUsuario> findByContenido(String contenido);
}