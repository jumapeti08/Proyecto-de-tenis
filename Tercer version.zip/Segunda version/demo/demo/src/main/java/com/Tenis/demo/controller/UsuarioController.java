package com.Tenis.demo.controller;

import com.Tenis.demo.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/usuarios")
@CrossOrigin(origins = "*")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    // Agregamos este método para probar si el controlador funciona
    @GetMapping("/test")
    public String test() {
        return "El controlador de usuarios está activo";
    }

    @PostMapping("/registrar")
    public ResponseEntity<?> registrarNuevoUsuario(@RequestBody Map<String, String> request) {
        try {
            String user = request.get("usuario");
            String pass = request.get("password");
            int rolId = Integer.parseInt(request.get("rolId"));

            usuarioService.registrarUsuario(user, pass, rolId);
            return ResponseEntity.ok(Map.of("message", "Usuario " + user + " creado con éxito"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}