package com.Tenis.demo.model.entities;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Rol {
    @Id
    private int idRol; //
    private String nombre; //
    
    @ManyToMany
    @JoinTable(name = "rol_permisos")
    private List<Permiso> permisos; //
    
    // Getters y Setters
    public int getIdRol() {
        return idRol;
    }
    
    public void setIdRol(int idRol) {
        this.idRol = idRol;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public List<Permiso> getPermisos() {
        return permisos;
    }
    
    public void setPermisos(List<Permiso> permisos) {
        this.permisos = permisos;
    }
}