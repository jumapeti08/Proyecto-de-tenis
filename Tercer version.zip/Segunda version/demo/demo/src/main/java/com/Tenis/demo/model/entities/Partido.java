package com.Tenis.demo.model.entities;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(name = "partidos")
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "@class")
@JsonSubTypes({
    @JsonSubTypes.Type(value = PartidoSencillos.class, name = "com.Tenis.demo.model.entities.PartidoSencillos"),
    @JsonSubTypes.Type(value = PartidoDobles.class, name = "com.Tenis.demo.model.entities.PartidoDobles")
})
public abstract class Partido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    private EstadoPartido estado; // SIN_JUGAR, EN_JUEGO, FINALIZADO
    private LocalDate fecha;
    private String resultado; // Ej: "6-4 3-6 7-5"

    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "estadisticas_id", referencedColumnName = "id")
    private EstadisticasPartido estadisticas;

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public EstadoPartido getEstado() {
        return estado;
    }

    public void setEstado(EstadoPartido estado) {
        this.estado = estado;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }

    public EstadisticasPartido getEstadisticas() {
        return estadisticas;
    }

    public void setEstadisticas(EstadisticasPartido estadisticas) {
        this.estadisticas = estadisticas;
    }

    public enum EstadoPartido {
        SIN_JUGAR,
        EN_JUEGO,
        FINALIZADO
    }
}