package com.Tenis.demo.service;

import com.Tenis.demo.model.entities.TokenUsuario;
import com.Tenis.demo.model.entities.Usuario;
import com.Tenis.demo.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthService {
    @Autowired
    private UsuarioRepository usuarioRepository;

    public TokenUsuario autenticar(String username, String password) {
        // 1. Buscamos en la base de datos por el nombre de usuario
        Usuario usuario = usuarioRepository.findByUsuario(username)
            .orElseThrow(() -> new RuntimeException("El usuario no existe en la BD"));

        // 2. Comparamos la contraseña (en texto plano por ahora)
        if (usuario.getPassword().equals(password)) {
            // 3. Si es correcto, devolvemos su token y rol que YA están en la BD
            return usuario.getToken();
        }
        
        throw new RuntimeException("Contraseña incorrecta");
    }
}