package com.Tenis.demo.controller;

import com.Tenis.demo.model.entities.Jugador;
import com.Tenis.demo.model.entities.Partido;
import com.Tenis.demo.model.entities.PartidoSencillos;
import com.Tenis.demo.repository.JugadorRepository;
import com.Tenis.demo.repository.PartidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/jugadores")
@CrossOrigin(origins = "*")
public class JugadorController {

    @Autowired
    private JugadorRepository jugadorRepository;

    @Autowired
    private PartidoRepository partidoRepository;

    // Búsqueda con sugerencias (top 10)
    @GetMapping("/search")
    public List<Jugador> searchJugadores(@RequestParam(name = "q", required = false, defaultValue = "") String q) {
        if (q == null || q.isBlank()) return List.of();
        return jugadorRepository.findTop10ByNombreContainingIgnoreCase(q);
    }

    // Obtener partidos en los que participa un jugador (sencillos)
    @GetMapping("/{id}/partidos")
    public ResponseEntity<List<Partido>> getPartidosByJugador(@PathVariable Long id) {
        List<Partido> relacionados = new ArrayList<>();
        partidoRepository.findAll().forEach(p -> {
            if (p instanceof PartidoSencillos) {
                PartidoSencillos ps = (PartidoSencillos) p;
                if ((ps.getJugador1() != null && id.equals(ps.getJugador1().getId())) ||
                        (ps.getJugador2() != null && id.equals(ps.getJugador2().getId()))) {
                    relacionados.add(p);
                }
            }
        });
        return ResponseEntity.ok(relacionados);
    }

    // Resumen simple de estadísticas: número de partidos encontrados y lista de partidos
    @GetMapping("/{id}/estadisticas")
    public ResponseEntity<?> getEstadisticasBasicas(@PathVariable Long id) {
        List<Partido> relacionados = new ArrayList<>();
        partidoRepository.findAll().forEach(p -> {
            if (p instanceof PartidoSencillos) {
                PartidoSencillos ps = (PartidoSencillos) p;
                if ((ps.getJugador1() != null && id.equals(ps.getJugador1().getId())) ||
                        (ps.getJugador2() != null && id.equals(ps.getJugador2().getId()))) {
                    relacionados.add(p);
                }
            }
        });
        var resumen = java.util.Map.of(
                "jugadorId", id,
                "totalPartidos", relacionados.size(),
                "partidos", relacionados
        );
        return ResponseEntity.ok(resumen);
    }
}
