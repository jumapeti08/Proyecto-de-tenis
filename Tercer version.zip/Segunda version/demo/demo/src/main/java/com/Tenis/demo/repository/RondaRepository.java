package com.Tenis.demo.repository;

import com.Tenis.demo.model.entities.Ronda;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RondaRepository extends JpaRepository<Ronda, Long> {
}