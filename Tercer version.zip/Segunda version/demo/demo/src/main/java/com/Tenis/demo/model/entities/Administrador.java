package com.Tenis.demo.model.entities;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "administradores")
public class Administrador extends Usuario {
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_administrador")
    private List<Torneo> torneos; //
    
    // Getters y Setters
    
    public List<Torneo> getTorneos() {
        return torneos;
    }
    
    public void setTorneos(List<Torneo> torneos) {
        this.torneos = torneos;
    }
}   