package com.Tenis.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class NavegacionController {

    @GetMapping("/admin")
    public String irAlAdmin() {
        // Busca en static/CrearTorneo/Admin.html
        return "/CrearTorneo/Admin.html"; 
    }

    @GetMapping("/juez")
    public String irAlJuez() {
        // Busca en static/Juez/index.html
        return "/Juez/index.html";
    }
}