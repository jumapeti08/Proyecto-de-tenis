package com.Tenis.demo.repository;

import com.Tenis.demo.model.entities.EstadisticasPartido;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EstadisticasPartidoRepository extends JpaRepository<EstadisticasPartido, Long> {
}