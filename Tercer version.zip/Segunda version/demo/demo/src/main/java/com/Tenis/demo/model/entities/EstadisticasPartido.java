package com.Tenis.demo.model.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "estadisticas_partido")
public class EstadisticasPartido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Estadísticas para el Jugador/Pareja 1
    private Integer aces1;
    private Integer doblesFaltas1;
    private Integer erroresNoForzados1;
    private Integer golpesGanadores1;

    // Estadísticas para el Jugador/Pareja 2
    private Integer aces2;
    private Integer doblesFaltas2;
    private Integer erroresNoForzados2;
    private Integer golpesGanadores2;

    // Constructor, Getters y Setters
    public EstadisticasPartido() {
        this.aces1 = 0;
        this.doblesFaltas1 = 0;
        this.erroresNoForzados1 = 0;
        this.golpesGanadores1 = 0;
        this.aces2 = 0;
        this.doblesFaltas2 = 0;
        this.erroresNoForzados2 = 0;
        this.golpesGanadores2 = 0;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getAces1() {
        return aces1;
    }

    public void setAces1(Integer aces1) {
        this.aces1 = aces1;
    }

    public Integer getDoblesFaltas1() {
        return doblesFaltas1;
    }

    public void setDoblesFaltas1(Integer doblesFaltas1) {
        this.doblesFaltas1 = doblesFaltas1;
    }

    public Integer getErroresNoForzados1() {
        return erroresNoForzados1;
    }

    public void setErroresNoForzados1(Integer erroresNoForzados1) {
        this.erroresNoForzados1 = erroresNoForzados1;
    }

    public Integer getGolpesGanadores1() {
        return golpesGanadores1;
    }

    public void setGolpesGanadores1(Integer golpesGanadores1) {
        this.golpesGanadores1 = golpesGanadores1;
    }

    public Integer getAces2() {
        return aces2;
    }

    public void setAces2(Integer aces2) {
        this.aces2 = aces2;
    }

    public Integer getDoblesFaltas2() {
        return doblesFaltas2;
    }

    public void setDoblesFaltas2(Integer doblesFaltas2) {
        this.doblesFaltas2 = doblesFaltas2;
    }

    public Integer getErroresNoForzados2() {
        return erroresNoForzados2;
    }

    public void setErroresNoForzados2(Integer erroresNoForzados2) {
        this.erroresNoForzados2 = erroresNoForzados2;
    }

    public Integer getGolpesGanadores2() {
        return golpesGanadores2;
    }

    public void setGolpesGanadores2(Integer golpesGanadores2) {
        this.golpesGanadores2 = golpesGanadores2;
    }
}