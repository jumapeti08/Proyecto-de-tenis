package com.Tenis.demo.service;

import com.Tenis.demo.model.entities.Administrador;
import com.Tenis.demo.model.entities.Rol;
import com.Tenis.demo.model.entities.TokenUsuario;
import com.Tenis.demo.repository.RolRepository;
import com.Tenis.demo.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.UUID;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private RolRepository rolRepository;

    @Transactional
    public void registrarUsuario(String username, String password, int idRol) {
        if (usuarioRepository.findByUsuario(username).isPresent()) {
            throw new RuntimeException("El nombre de usuario '" + username + "' ya está en uso.");
        }

        Rol rol = rolRepository.findById(idRol)
                .orElseThrow(() -> new RuntimeException("Rol no encontrado"));

        TokenUsuario token = new TokenUsuario();
        token.setContenido(UUID.randomUUID().toString()); // Genera un token único
        token.setExpiracion("2026-12-31");
        token.setRol(rol);

        // Usamos Administrador como clase base para todos por ahora 
        // (puedes crear clases Juez o Jugador que extiendan de Usuario después)
        Administrador nuevoUsuario = new Administrador();
        nuevoUsuario.setUsuario(username);
        nuevoUsuario.setPassword(password);
        nuevoUsuario.setToken(token);

        usuarioRepository.save(nuevoUsuario);
    }
}