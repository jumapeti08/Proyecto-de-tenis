package com.Tenis.demo.model.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "usuarios")
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idUsuario; //
    private String usuario; //
    private String password; //

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_token")
    private TokenUsuario token; //
    
    // Getters y Setters
    public int getIdUsuario() {
        return idUsuario;
    }
    
    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }
    
    public String getUsuario() {
        return usuario;
    }
    
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public TokenUsuario getToken() {
        return token;
    }
    
    public void setToken(TokenUsuario token) {
        this.token = token;
    }
}