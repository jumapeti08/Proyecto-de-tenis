package com.Tenis.demo.model.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "partidos_sencillos")
@PrimaryKeyJoinColumn(name = "partido_id")
public class PartidoSencillos extends Partido {

    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE}) // Persistir jugadores si son nuevos
    @JoinColumn(name = "jugador1_id")
    private Jugador jugador1;

    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE}) // Persistir jugadores si son nuevos
    @JoinColumn(name = "jugador2_id")
    private Jugador jugador2;

    // Getters y Setters
    public Jugador getJugador1() {
        return jugador1;
    }

    public void setJugador1(Jugador jugador1) {
        this.jugador1 = jugador1;
    }

    public Jugador getJugador2() {
        return jugador2;
    }

    public void setJugador2(Jugador jugador2) {
        this.jugador2 = jugador2;
    }
}