package com.Tenis.demo.model.entities;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "rondas")
public class Ronda {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Integer numeroRonda; // Ej: 1, 2, 3 (Cuartos, Semis, Final)
    private String nombreRonda; // Ej: "Ronda 1", "Cuartos de Final", "Semifinal", "Final"

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "ronda_id") // Columna en la tabla de partidos que referencia a la ronda
    private List<Partido> partidos;

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getNumeroRonda() {
        return numeroRonda;
    }

    public void setNumeroRonda(Integer numeroRonda) {
        this.numeroRonda = numeroRonda;
    }

    public String getNombreRonda() {
        return nombreRonda;
    }

    public void setNombreRonda(String nombreRonda) {
        this.nombreRonda = nombreRonda;
    }

    public List<Partido> getPartidos() {
        return partidos;
    }

    public void setPartidos(List<Partido> partidos) {
        this.partidos = partidos;
    }
}