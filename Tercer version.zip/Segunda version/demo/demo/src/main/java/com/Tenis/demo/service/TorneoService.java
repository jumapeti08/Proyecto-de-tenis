package com.Tenis.demo.service;

import com.Tenis.demo.model.entities.*;
import com.Tenis.demo.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;



import java.time.LocalDate;


@Service
public class TorneoService {

    @Autowired
    private TorneoRepository torneoRepository;
    @Autowired
    private JugadorRepository jugadorRepository;
    @Autowired
    private ParejaRepository parejaRepository;

    @Transactional
    public Torneo crearTorneo(Torneo torneo) {
        // Asegurarse de que los jugadores y parejas existan o se creen antes de guardar partidos
        if (torneo.getRondas() != null) {
            for (Ronda ronda : torneo.getRondas()) {
                if (ronda.getPartidos() != null) {
                    for (Partido partido : ronda.getPartidos()) {
                        partido.setFecha(LocalDate.now()); // Asignar fecha actual por defecto
                        partido.setEstado(Partido.EstadoPartido.SIN_JUGAR); // Estado inicial

                        if (partido instanceof PartidoSencillos) {
                            PartidoSencillos ps = (PartidoSencillos) partido;
                            ps.setJugador1(findOrCreateJugador(ps.getJugador1().getNombre()));
                            ps.setJugador2(findOrCreateJugador(ps.getJugador2().getNombre()));
                        } else if (partido instanceof PartidoDobles) {
                            PartidoDobles pd = (PartidoDobles) partido;
                            pd.setPareja1(findOrCreatePareja(pd.getPareja1()));
                            pd.setPareja2(findOrCreatePareja(pd.getPareja2()));
                        }
                        // Las estadísticas se inicializan en el constructor de EstadisticasPartido
                        if (partido.getEstadisticas() == null) {
                            partido.setEstadisticas(new EstadisticasPartido());
                        }
                    }
                }
            }
        }
        torneo.setEstado(Torneo.EstadoTorneo.SIN_JUGAR); // Estado inicial del torneo
        return torneoRepository.save(torneo);
    }

    private Jugador findOrCreateJugador(String nombreJugador) {
        return jugadorRepository.findByNombre(nombreJugador)
                .orElseGet(() -> {
                    Jugador nuevoJugador = new Jugador();
                    nuevoJugador.setNombre(nombreJugador);
                    return jugadorRepository.save(nuevoJugador);
                });
    }

    private Pareja findOrCreatePareja(Pareja pareja) {
        // Una implementación más robusta buscaría por jugador1_id Y jugador2_id
        // Para evitar duplicados, se necesitaría una consulta personalizada en ParejaRepository.
        // Ejemplo: Optional<Pareja> findByJugador1AndJugador2OrJugador2AndJugador1(Jugador j1, Jugador j2);

        Jugador j1 = findOrCreateJugador(pareja.getJugador1().getNombre());
        Jugador j2 = findOrCreateJugador(pareja.getJugador2().getNombre());

        Pareja nuevaPareja = new Pareja();
        nuevaPareja.setJugador1(j1);
        nuevaPareja.setJugador2(j2);
        return parejaRepository.save(nuevaPareja);
    }
}