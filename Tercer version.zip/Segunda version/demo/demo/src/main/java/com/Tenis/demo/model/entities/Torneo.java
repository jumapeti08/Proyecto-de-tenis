package com.Tenis.demo.model.entities;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "torneos")
public class Torneo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nombre; // Podría ser el nombre del torneo
    private String categoria; // "Sencillos" o "Dobles"

    @Enumerated(EnumType.STRING)
    private EstadoTorneo estado; // SIN_JUGAR, EN_JUEGO, FINALIZADO

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "torneo_id") // Columna en la tabla de rondas que referencia al torneo
    private List<Ronda> rondas;

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public EstadoTorneo getEstado() {
        return estado;
    }

    public void setEstado(EstadoTorneo estado) {
        this.estado = estado;
    }

    public List<Ronda> getRondas() {
        return rondas;
    }

    public void setRondas(List<Ronda> rondas) {
        this.rondas = rondas;
    }

    public enum EstadoTorneo {
        SIN_JUGAR,
        EN_JUEGO,
        FINALIZADO
    }
}