package com.Tenis.demo.model.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "tokens")
public class TokenUsuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idToken; //
    private String contenido; //
    private String expiracion; //

    @ManyToOne
    @JoinColumn(name = "id_rol")
    private Rol rol; //
    
    // Getters y Setters
    public int getIdToken() {
        return idToken;
    }
    
    public void setIdToken(int idToken) {
        this.idToken = idToken;
    }
    
    public String getContenido() {
        return contenido;
    }
    
    public void setContenido(String contenido) {
        this.contenido = contenido;
    }
    
    public String getExpiracion() {
        return expiracion;
    }
    
    public void setExpiracion(String expiracion) {
        this.expiracion = expiracion;
    }
    
    public Rol getRol() {
        return rol;
    }
    
    public void setRol(Rol rol) {
        this.rol = rol;
    }
}