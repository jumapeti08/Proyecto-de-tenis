package com.Tenis.demo.model.entities;
/* Este archivo está vacío para evitar duplicidad con com.Tenis.demo.service.UsuarioService */