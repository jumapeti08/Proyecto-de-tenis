package com.Tenis.demo.model.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "partidos_dobles")
@PrimaryKeyJoinColumn(name = "partido_id")
public class PartidoDobles extends Partido {

    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE}) // Persistir parejas si son nuevas
    @JoinColumn(name = "pareja1_id")
    private Pareja pareja1;

    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE}) // Persistir parejas si son nuevas
    @JoinColumn(name = "pareja2_id")
    private Pareja pareja2;

    // Getters y Setters
    public Pareja getPareja1() {
        return pareja1;
    }

    public void setPareja1(Pareja pareja1) {
        this.pareja1 = pareja1;
    }

    public Pareja getPareja2() {
        return pareja2;
    }

    public void setPareja2(Pareja pareja2) {
        this.pareja2 = pareja2;
    }
}