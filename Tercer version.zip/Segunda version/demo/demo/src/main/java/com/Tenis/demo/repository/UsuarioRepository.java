package com.Tenis.demo.repository;

import com.Tenis.demo.model.entities.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {
    // Permite buscar por nombre de usuario para el login
    Optional<Usuario> findByUsuario(String usuario);
}