
package com.Tenis.demo.dto;

public class LoginRequest {
    // Estos nombres deben ser iguales a los del JSON en tu JS
    private String usuario; 
    private String password;

    // Es obligatorio tener un constructor vacío para JPA/Jackson
    public LoginRequest() {}

    public LoginRequest(String usuario, String password) {
        this.usuario = usuario;
        this.password = password;
    }

    // Getters y Setters (Fundamentales para que Spring lea los datos)
    public String getUsuario() { return usuario; }
    public void setUsuario(String usuario) { this.usuario = usuario; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
}