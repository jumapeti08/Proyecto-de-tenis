package com.Tenis.demo.repository;

import com.Tenis.demo.model.entities.Torneo;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TorneoRepository extends JpaRepository<Torneo, Long> {
    List<Torneo> findByEstadoNot(Torneo.EstadoTorneo estado);
}