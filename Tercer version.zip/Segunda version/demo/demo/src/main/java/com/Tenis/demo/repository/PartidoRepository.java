package com.Tenis.demo.repository;

import com.Tenis.demo.model.entities.Partido;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PartidoRepository extends JpaRepository<Partido, Long> {
}