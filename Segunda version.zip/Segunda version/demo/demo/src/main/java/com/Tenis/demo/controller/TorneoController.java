package com.Tenis.demo.controller;

import com.Tenis.demo.model.entities.Partido;
import com.Tenis.demo.model.entities.Torneo;
import com.Tenis.demo.repository.PartidoRepository;
import com.Tenis.demo.repository.TorneoRepository;
import com.Tenis.demo.service.TorneoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/torneos")
@CrossOrigin(origins = "*")
public class TorneoController {

    @Autowired
    private TorneoService torneoService;

    @Autowired
    private TorneoRepository torneoRepository;

    @Autowired
    private PartidoRepository partidoRepository;

    @PostMapping
    public ResponseEntity<?> crearTorneo(@RequestBody Torneo torneo) {
        Torneo nuevoTorneo = torneoService.crearTorneo(torneo);
        return ResponseEntity.ok(nuevoTorneo);
    }

    @GetMapping("/activos")
    public List<Torneo> getTorneosActivos() {
        return torneoRepository.findByEstadoNot(Torneo.EstadoTorneo.FINALIZADO);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Torneo> getTorneo(@PathVariable Long id) {
        return torneoRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/partidos/{id}")
    public ResponseEntity<Partido> getPartido(@PathVariable Long id) {
        return partidoRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}